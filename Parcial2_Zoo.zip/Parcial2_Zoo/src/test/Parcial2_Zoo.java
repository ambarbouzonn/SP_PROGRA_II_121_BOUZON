package test;
import servicio.Zoologico;
import modelo.TipoAlimentacion;
import modelo.Animal;
import java.io.IOException;

public class Parcial2_Zoo {
    public static void main(String[] args) throws ClassNotFoundException {
        try {
            Zoologico<Animal> zoologico = new Zoologico<>();

            // Agregar animales
            zoologico.agregar(new Animal(1, "Leon", "Panthera leo", TipoAlimentacion.CARNIVORO));
            zoologico.agregar(new Animal(2, "Elefante", "Loxodonta", TipoAlimentacion.HERBIVORO));
            zoologico.agregar(new Animal(3, "Oso", "Ursus arctos", TipoAlimentacion.OMNIVORO));
            zoologico.agregar(new Animal(4, "Zorro", "Vulpes vulpes", TipoAlimentacion.CARNIVORO));
             zoologico.agregar(new Animal(5, "Gorila", "Gorilla gorilla", TipoAlimentacion.OMNIVORO));
             
             
            // Mostrar todos los animales en el zoológico
            System.out.println("Inventario de animales:");
            zoologico.paraCadaElemento(System.out::println);

            // Filtrar animales por tipo de alimentación CARNIVORO
            System.out.println("\nAnimales CARNIVOROS:");
            zoologico.filtrar(animal -> animal.getAlimentacion() == TipoAlimentacion.CARNIVORO)
                     .forEach(System.out::println);

            // Filtrar por nombre que contiene "Leon"
            System.out.println("\nAnimales cuyo nombre contiene 'Leon':");
            zoologico.filtrar(animal -> animal.getNombre().contains("Leon"))
                     .forEach(System.out::println);

            // Ordenar por ID
            zoologico.ordenar();
            System.out.println("\nAnimales ordenados por ID:");
            zoologico.paraCadaElemento(System.out::println);

            // Ordenar animales por nombre utilizando un Comparator
            System.out.println("\nAnimales ordenados por nombre:");
            zoologico.ordenar((a1, a2) -> a1.getNombre().compareTo(a2.getNombre()));
            zoologico.paraCadaElemento(System.out::println);

            // Guardar el zoológico en un archivo binario
            zoologico.guardarEnArchivo("src/data/animales.dat");
            
            // Cargar el zoológico desde el archivo binario
            Zoologico<Animal> zoologicoCargado = new Zoologico<>();
            zoologicoCargado.cargarDesdeArchivo("src/data/animales.dat");
            System.out.println("\nAnimales cargados desde archivo binario:");
            zoologicoCargado.paraCadaElemento(animal -> System.out.println(animal));

            
            // Guardar el zoológico en un archivo CSV
            zoologico.guardarEnCSV("src/data/animales.csv");
            
            // Cargar el zoológico desde el archivo CSV
            zoologicoCargado.cargarDesdeCSV("src/data/animales.csv", linea ->
            Animal.fromCSV(linea));
            System.out.println("\nAnimales cargados desde archivo CSV:");
            zoologicoCargado.paraCadaElemento(animal -> System.out.println(animal));
            
            
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }   
    }
}
