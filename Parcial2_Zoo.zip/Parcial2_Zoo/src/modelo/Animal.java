package modelo;
import java.io.Serializable;

public class Animal implements Comparable<Animal>, CSVSerializable, Serializable {
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }
    
    public int compareTo(Animal otro) {
        return Integer.compare(this.id, otro.id);
    }
    
    public String toCSV() {
        return id + ", " + nombre + ", " + especie + ", " + alimentacion;
    }
    
    public static Animal fromCSV(String csv) {
        String[] datos = csv.split(",");
        return new Animal(
            Integer.parseInt(datos[0].trim()), 
            datos[1].trim(),                   
            datos[2].trim(),                 
            TipoAlimentacion.valueOf(datos[3].trim()) 
        );
    }

    @Override
    public String toString() {
        return "Animal:" +
                " id= " + id +
                ", nombre= '" + nombre + '\'' +
                ", especie= '" + especie + '\'' +
                ", alimentacion= " + alimentacion +
                '}';
    }

}
