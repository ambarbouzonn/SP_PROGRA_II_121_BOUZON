package modelo;

public enum TipoAlimentacion {
    CARNIVORO,
    HERBIVORO,
    OMNIVORO,
    INSECTIVORO;
}
