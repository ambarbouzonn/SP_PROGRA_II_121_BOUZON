package servicio;
import modelo.CSVSerializable;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;


public class Zoologico<T extends CSVSerializable & Comparable<? super T>> {
    private List<T> inventario = new ArrayList<>();
    
    public void agregar(T elemento) {
        inventario.add(elemento);
    }
    
    public T obtener(int indice) {
        return inventario.get(indice);
    }
    
    public void eleminar(int indice) {
        inventario.remove(indice);
    }
    
    public List<T> filtrar(Predicate<T> criterio){
        List<T> filtrados = new ArrayList<>();
        for (T elemento : inventario) {
            if (criterio.test(elemento)) {
                filtrados.add(elemento);
            }
        }
        return filtrados;
    } 
    
    // Ordenar usando el orden natural
    public void ordenar() {
        Collections.sort(inventario);
    }

    // Ordenar usando un Comparator
    public void ordenar(Comparator<? super T> comparator) {
        inventario.sort(comparator);
    }
    
    // Guardar en archivo binario
    public void guardarEnArchivo(String archivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(inventario);
        }
    }
    
    // Cargar desde el archivo binario
    public void cargarDesdeArchivo(String archivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            inventario = (List<T>) ois.readObject();
        }
    }
    
    // Guardar en archivo CSV
    public void guardarEnCSV(String archivo) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
            for (T elemento : inventario) {
                bw.write(elemento.toCSV());
                bw.newLine();
            }
        }
    }
    
    // Cargar desde el archivo CSV
    public void cargarDesdeCSV(String archivo, FuncionDesdeCSV<T> parser) throws IOException {
        inventario.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                agregar(parser.desdeCSV(linea));
            }
        }
}

    public void paraCadaElemento(java.util.function.Consumer<T> accion) {
        for (T elemento : inventario) {
            accion.accept(elemento);
        }
    }
    
    public interface FuncionDesdeCSV<T> {
        T desdeCSV(String csv);
    }
 
}
